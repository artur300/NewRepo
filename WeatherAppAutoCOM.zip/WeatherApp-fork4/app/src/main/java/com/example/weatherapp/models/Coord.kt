package com.example.weatherapp.models

data class Coord(
    val lat: Double,
    val lon: Double
)