package com.example.weatherapp.util

class Constants {
    companion object{
        const val API_KEY = "7cf2df64d4a5802974c532f225a732ad"

        const val BASE_URL = "https://api.openweathermap.org"
    }
}