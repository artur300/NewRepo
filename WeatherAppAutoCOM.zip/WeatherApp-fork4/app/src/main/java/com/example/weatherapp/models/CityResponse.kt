package com.example.weatherapp.models

//-----------arthur code-----------------
data class CityResponse(
    val name: String,
    val lat: Double,
    val lon: Double,
    val country: String

//-------------------------------------
)