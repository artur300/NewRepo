package com.example.weatherapp.models

data class Clouds(
    val all: Int
)